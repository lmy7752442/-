<?php
namespace frameWork\Libr;
class Upload{

	private $error;
	public $type;   //需要定义
	public $size;   //需要定义
	public $dir;    //可以定义

	function up($file){

		//验证
		switch($file['error']){
			case 1:$this->error = '您的文件大小超过php.ini的设置';return false;
			case 2:$this->error = '您的文件大小超过表单的设置';return false;
			case 3:$this->error = '文件部分上传';return false;
			case 4:$this->error = '没有文件上传';return false;
		}

		$str = substr($file['type'],strrpos($file['type'],'/')+1);
		$type = implode(',',$this->type);
		if(!in_array($str,$this->type)){
			$this->error = '请放入'.$type.'格式文件';
			return false;
		}

		$size = $this->size/1024;
		if($file['size']>$this->size){
			$this->error = '请放入大小在'.$size.'Kb之内的文件';
			return false;
		}
		//拼接文件名
		$new_name = time().rand(10000,99999).substr($file['name'],strrpos($file['name'],'.'));
		//设置文件目录
		if(empty($this->dir)){
			$this->dir = date('Y').'/'.date('m').'/'.date('d').'/';
		}
		
		is_dir($this->dir) or mkdir($this->dir,0777,true);
		
		//拼接路径
		$path = $this->dir.$new_name;

		//返回
		$res = move_uploaded_file($file['tmp_name'],$path);
		if($res){
			return $path;
		}else{
			return $this->error;
		}
	
	}
	//错误函数
	function errors(){
		return $this->error;
	}



}







?>