<?php
namespace frameWork\Libr;
class Page{
	private $page_num;	                           //总条数							
	private $p;									   //当前页码
	public $offset = 2;							   //当页前后条数
	public $style = array('up'=>'<<','down'=>'>>');//上下页样式

	/**
	*Page construct
	*@param 总条数
	*@param 当页显示条数
	*/
	function __construct($count,$content){

		//接取当前页数
		$this->p = empty($_GET['p'])?1:$_GET['p'];

		//计算总页数
		$this->page_num = ceil($count/$content);
	}
	/**
	*php数字页码
	*/
	function phpPage(){

		//处理上下页
		$up = $this->p-1<1?1:$this->p-1;
		$down = $this->p+1>$this->page_num?$this->page_num:$this->p+1;
		
		//加上一页
        if(ROUTE_METHOD == 1){
            $str = "<a href='".URL_PATH."?c=".CONTROLLER_NAME."&a=".ACTION_NAME."&p=$up'>".$this->style['up']."</a>&nbsp;&nbsp;";
        }else{
            $str = "<a href='".URL_PATH.'/'.CONTROLLER_NAME.'/'.ACTION_NAME."/p/$up'>".$this->style['up']."</a>&nbsp;&nbsp;";
        }
		//$str = "<a href='?p=".$up."'>".$this->style['up']."</a>&nbsp;&nbsp;";

		//设置开始结束值
		$start = $this->p-$this->offset;
		$end = $this->p+$this->offset;

		//判断
		if($this->page_num<$this->offset*2+1){
			$end = $this->page_num;
			$start = 1;
		}else if($start<1){
			$start = 1;
			$end = 1+$this->offset*2;
		}else if($end>$this->page_num){
			$end = $this->page_num;
			$start = $end-$this->offset*2;
		}

		//展示
		for($i=$start;$i<=$end;$i++){
			if($this->p==$i){
				$str .= "<span style='font-size:22px;color:red;'>$i</span>&nbsp;&nbsp;";
			}else{
                if(ROUTE_METHOD == 1){
                    $str .= "<a href='".URL_PATH."?c=".CONTROLLER_NAME."&a=".ACTION_NAME."&p=$i'>$i</a>&nbsp;&nbsp;";
                }else{
                    $str .= "<a href='".URL_PATH.'/'.CONTROLLER_NAME.'/'.ACTION_NAME."/p/$i'>$i</a>&nbsp;&nbsp;";
                }

			}
		}

		//加下一页
        if(ROUTE_METHOD == 1){
            $str .= "<a href='".URL_PATH."?c=".CONTROLLER_NAME."&a=".ACTION_NAME."&p=$down'>".$this->style['down']."</a>&nbsp;&nbsp;";
        }else{
            $str .= "<a href='".URL_PATH.'/'.CONTROLLER_NAME.'/'.ACTION_NAME."/p/$down'>".$this->style['down']."</a>&nbsp;&nbsp;";
        }
		//$str .= "<a href='?p=".$down."'>".$this->style['down']."</a>&nbsp;&nbsp;";
		return $str;
	}

	/**
	*php上下页
	*/
	function phpUdPage(){
		$up = $this->p-1<1?1:$this->p-1;
		$down = $this->p+1>$this->page_num?$this->page_num:$this->p+1;
		$str = "<a href='?p=1'>首页</a>&nbsp;&nbsp;<a href='?p=$up'>上一页</a>&nbsp;&nbsp;<a href='?p=$down'>下一页</a>&nbsp;&nbsp;<a href='?p=$this->page_num'>尾页</a>&nbsp;&nbsp;";
		return $str;
		
	}
	
	/**
	*ajax数字页码
	*/
	function ajaxPage(){
		//处理上下页
		$up = $this->p-1<1?1:$this->p-1;
		$down = $this->p+1>$this->page_num?$this->page_num:$this->p+1;
		
		//加上一页
		$str = "<a href='javascript:;'onclick='page(".$up.")'>".$this->style['up']."</a>&nbsp;&nbsp;";

		//设置开始结束值
		$start = $this->p-$this->offset;
		$end = $this->p+$this->offset;

		//判断
		if($this->page_num<=$this->offset*2){
			$end = $this->page_num;
			$start = 1;
		}else if($start<1){
			$start = 1;
			$end = 1+$this->offset*2;
		}else if($end>$this->page_num){
			$end = $this->page_num;
			$start = $end-$this->offset*2;
		}

		//展示
		for($i=$start;$i<=$end;$i++){
			if($this->p==$i){
				$str .= "<a href='javascript:;' onclick='page($i)' style='font-size:22px;color:red;'>$i</a>&nbsp;&nbsp;";
			}else{
				$str .= "<a href='javascript:;' onclick='page($i)'>$i</a>&nbsp;&nbsp;";
			}
		}

		//加下一页
		$str .= "<a href='javascript:;'onclick='page(".$down.")'>".$this->style['down']."</a>&nbsp;&nbsp;";
		return $str;
	}
	
	/**
	*ajax上下页
	*/
	function ajaxUdPage(){
		$up = $this->p-1<1?1:$this->p-1;
		$down = $this->p+1>$this->page_num?$this->page_num:$this->p+1;
		$str = "<a href='javascript:;' onclick='page(1)'>首页</a>&nbsp;&nbsp;<a href='javascript:;' onclick='page($up)'>上一页</a>&nbsp;&nbsp;<a href='javascript:;' onclick='page($down)'>下一页</a>&nbsp;&nbsp;<a href='javascript:;' onclick='page($this->page_num)'>尾页</a>&nbsp;&nbsp;";
		return $str;
		
	}


}	
?>