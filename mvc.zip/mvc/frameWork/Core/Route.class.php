<?php 
namespace frameWork\Core;
if(!defined('ROOT_PATH')){
	exit('not allow access');
}
class Route{
	private static $controller_name;
	private static $action_name;
	

	static function start(){
		# 格式化代码
		echo '<pre>';

		# 判断是哪种路由器格式

		# 普通的路由模式 a=index&c=index	$_SERVER['QUERY_STRING']
		# 重写的路由模式 /index/index		$_SERVER['PATH_INFO']
		if(empty($_SERVER['PATH_INFO'])){
			# 普通方法
            define('ROUTE_METHOD',1);
			self::common();
		}else{
			# 重写方法
            define('ROUTE_METHOD',2);
			self::rewrite();
		}
	}

	/**
	*普通方法
	*/
	static function common(){

		# 接受参数如果有参数把参数都变成小写
		if(!empty($_GET)){
			$_GET = array_change_key_case($_GET);
		}

		# 接受要访问的控制器 -- 如果没有默认访问IndexController
		if(!empty($_GET['c'])){
			self::$controller_name = Ucfirst(strtolower($_GET['c'])).'Controller';
		}else{
			self::$controller_name = 'IndexController';
		}
		# 接受要访问的方法 -- 如果没有默认访问indexAction
		if(!empty($_GET['a'])){
			self::$action_name = strtolower($_GET['a']).'Action';
		}else{
			self::$action_name = 'indexAction';
		}
		
		self::pluAct();
		
	}

	/**
	*重写方法
	*/
	static function rewrite(){
		$arr = explode('/',ltrim($_SERVER['PATH_INFO'],'/'));
		self::$controller_name = ucfirst(strtolower(array_shift($arr)));
		self::$action_name = strtolower(array_shift($arr));
		$arr = array_filter($arr);
		$count = count($arr);
		$param = array();
		for($i=0;$i<$count;$i = $i+2){
			if(empty($arr[$i+1])){
				$arr[$i] = '';
			}else{
				$param[$arr[$i]] = $arr[$i+1];
			}
		}
		//print_r($param);exit;
       // var_dump($_GET);exit;
		$_GET = array_merge($_GET,$param);
		if(empty(self::$action_name)){
			self::$action_name = 'index';
		}
		self::$controller_name = self::$controller_name.'Controller';
		self::$action_name = self::$action_name.'Action';
		self::pluAct();
	
	}

	/**
	*调用方法
	*/
	static function pluAct(){
		$file = './app/Controller/'.self::$controller_name.'.class.php';
		if(file_exists($file)){
			//include $file;
            define('CONTROLLER_NAME',str_replace('Controller','',self::$controller_name));
			self::$controller_name = '\app\Controller\\'.self::$controller_name;
			$obj = new self::$controller_name;
			if( ! method_exists( $obj , self::$action_name )){
				echo self::$controller_name.' NOfind '.self::$action_name;
			}else{
                define('ACTION_NAME',str_replace('Action','',self::$action_name));
				$action = self::$action_name;
				$obj -> $action();
			}
		}else{
			echo 'NOfind '.$file;
		}


	}
}