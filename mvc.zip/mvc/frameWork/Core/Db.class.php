<?php 
namespace framework\Core;
final class Db{
	private $con;
	private $where;
	private $table;
	private static $num;
	//连接数据库
	private function __construct(){
		//$config = include (ROOT_PATH.'/app/config/config.php');
		$config = config();
		$this -> con = new \Mysqli($config['DB_HOST'],$config['DB_USER'],$config['DB_PWD'],$config['DB_NAME']);
		$this -> con -> query('set names utf8');
	}

	/**
	*and条件
	*@param $where
	*/
	function where($where){
		if(is_array($where)){
			foreach($where as $k => $v){
				$this -> where .= '`'.$k.'`='."'".$v."'".' and'; 
			}
			$this -> where = rtrim($this -> where,' and');
		}else{
			$this -> where .= ' and '.$where;
		}
		
		return $this;
	}
	/**
	*or条件
	*@param $where
	*/
	function orWhere($where){
		if($where){
			$this -> where .= ' or '.$where;
		}
		
		return $this;
	}


	/**
	*表名
	*@param $table
	*/
	function table($table){
		$this -> table = $table;
		return $this;
	}

	/**
	*查询一条
	*/
	function find(){
		$sql = 'select * from '.$this -> table;
		if($this -> where){
			$sql .= ' where 1'.$this -> where;
		}
		$res = $this -> con -> query($sql);
		if($res -> num_rows){
			$arr = $res -> fetch_assoc();
			return $arr;
		}else{
			return false;
		}
	}

	/**
	*查询多条
	*/
	function select(){
		$sql = 'select * from '.$this -> table;
		if($this -> where){
			$sql .= ' where 1'.$this -> where;
		}
		$res = $this -> con -> query($sql);
		if($res -> num_rows){
			$data = $res -> fetch_all(MYSQLI_ASSOC);
			return $data;
		}else{
			return false;
		}
	}
	/**
	*添加
	*@param $arr
	*@return 
	*/
	function add($arr){
		$str1 = '';
		$str2 = '';
		foreach($arr as $k => $v){
			$str1 .= $k.',';
			$str2 .= "'".$v."'".',';
		}
		$str1 = rtrim($str1,',');
		$str2 = rtrim($str2,',');
		$sql = 'insert into '.$this -> table.'('.$str1.')'.'values('.$str2.')';
		$res = $this -> con ->query($sql);
		$num =$this ->con -> insert_id;
		return $num;
	}
	
	/**
	*修改
	*@param $arr
	*/
	function save($arr){
		$str = '';
		foreach($arr as $k => $v){
			$str .= $k.'='."'".$v."'".',';
 		}
		$str = rtrim($str,',');
		$sql = 'update '.$this -> table.' set '.$str.' where 1 '.$this -> where;
		$res = $this -> con -> query($sql);
		$num = $this -> con -> affected_rows;
		return $num;
	}
	
	/**
	*删除
	*/
	function del(){
		$sql = 'delete from '.$this -> table.' where 1 '.$this -> where;
		$res = $this -> con -> query($sql);
		$num = $this -> con -> affected_rows;
		return $num;
	}
	
	/**
	*分页
	*/
	function page($p,$content){
		$start = ($p-1)*$content;
		$sql = 'select * from '.$this -> table.$this -> where.' limit '.$start.','.$content;
		$res = $this -> con -> query($sql);
		if($res -> num_rows){
			$data = $res -> fetch_all(MYSQLI_ASSOC);
			return $data;
		}else{
			return false;
		}
	}

	/**
	*总页数
	*/

	function count(){
		$sql = 'select count(*) as num from '.$this -> table.$this -> where;
		$arr = $this -> con -> query($sql) -> fetch_assoc();
		$num = $arr['num'];
		return $num;
	}

	/**
	*防止克隆
	*/
	private function __clone(){
		
	}
	/**
	*单例
	*/
	static function getObj(){
		if(!self::$num){
			self::$num = new self;
		}
		return self::$num;
	}
}

