<?php
namespace framework\Core;
class Controller{
    private $template_var = [];
    function display($view_name){
        extract($this -> template_var);
        include VIEW_PATH.'/'.$view_name.'.php';
    }
    function assign($var_name,$var_value){
        $this -> template_var[$var_name] = $var_value;
    }
}