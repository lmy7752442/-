<?php
namespace frameWork\Core;
class EasyMvc{

    /**
     * 框架开始
     */
    public static function start(){
        # 设置自动加载
        spl_autoload_register(__NAMESPACE__.'\EasyMvc::autoload');

        # 设置一些常量
        self::initDefine();

        # 加载需要加载的文件
        self::autoloadFile();

        # 加载路由文件
        Route::start();
    }

    public static function autoload($class_name){
        $file = str_replace('\\','/',ROOT_PATH.'/'.$class_name.'.class.php');
        include $file;
    }

    /**
     * 初始化一些常量
     */
    public static function initDefine(){
        # 定义一个常量
        defined('ROOT_PATH')? : define('ROOT_PATH',replaceDir( __DIR__ ));

        # 定义一个APP_PATH
        defined('APP_PATH')? : define('APP_PATH',ROOT_PATH.'/app');

        # 定义一个VIEW_PATH
        defined('VIEW_PATH')? : define('VIEW_PATH',APP_PATH.'/view');

        # 定义一个URL_PATH
        defined('URL_PATH')? : define('URL_PATH',$_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'].$_SERVER['SCRIPT_NAME']);
    }

    /**
     * 加载框架需要的文件 # 类文件除外
     */
    public static function autoloadFile(){
         include ROOT_PATH.'/app/Common/function.php';
    }
}