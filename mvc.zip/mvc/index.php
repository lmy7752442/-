<?php 
header('content-type:text/html;charset=utf8');
define('ROOT_PATH',str_replace('\\','/',__DIR__));

# 引入加载文件
//include ROOT_PATH.'/frameWork/autoload.php';

# 引入公共函数
/*include ROOT_PATH.'/app/Common/function.php';

function __autoload($class_name){
	$file = str_replace('/','\\',ROOT_PATH.'/'.$class_name.'.class.php');
	echo $file.'<hr>';
	include $file;
}*/
include __DIR__.'/frameWork/Core/EasyMvc.class.php';
\frameWork\Core\EasyMvc::start();