<?php
function config(){
	static $config;
	if(empty($config)){
		$config = include ROOT_PATH.'/app/config/config.php';
	}
	return $config;
}

function replaceDir($dir){
    return str_replace('\\','/',ROOT_PATH.'/'.$dir.'.class.php');
}
function url( $param ){

//    var_dump( URL_MODE );

    if( ROUTE_METHOD == 2 ){
        $url = URL_PATH . '/' . $param;
    }else{
        $arr = explode( '/' ,  $param );
        $url = URL_PATH . '?c=' . array_shift( $arr ) . '&a=' . array_shift( $arr);
    }

    return $url;
}

