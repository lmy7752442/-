<?php
namespace app\Model;
if(!defined('ROOT_PATH')){
	exit('not allow access');
}
class UserModel{
	function addAction($table,$arr){
		return \frameWork\Core\Db::getObj() -> table($table) -> add($arr);
	}
	function delAction($where){
		return \frameWork\Core\Db::getObj() -> table('admin') -> where($where) -> del();
	}
	function saveAction($arr,$where){
		return \frameWork\Core\Db::getObj() -> table('admin') -> where($where) -> save($arr);
	}
	function findAction($where){
		return \frameWork\Core\Db::getObj() -> table('admin') -> where($where) -> find();
	}
	function selectAction($table,$where=1){
        if($where == 1){
            return \frameWork\Core\Db::getObj() -> table($table) -> select();
        }else{
            return \frameWork\Core\Db::getObj() -> table($table) -> where($where) -> select();
        }
	}
    function pageAction($p,$content,$where=1){
        if($where=1){
            return \frameWork\Core\Db::getObj() -> table('admin') -> page($p,$content);
        }else{
            return \frameWork\Core\Db::getObj() -> table('admin') -> where($where) -> page($p,$content);
        }
    }
    function countAction($where=1){
        if($where=1){
            return \frameWork\Core\Db::getObj() -> table('admin') -> count();
        }else{
            return \frameWork\Core\Db::getObj() -> table('admin') -> where($where) -> count();
        }
    }

}