<?php
namespace app\Controller;
use frameWork\Libr\Page;
if(!defined('ROOT_PATH')){
    exit('not allow access');
}
class LoginController extends CommonController{
    function loginAction(){
        $this -> display('login/login');
    }
    function login_doAction(){
        $arr = $_POST;
        $obj = new \app\Model\UserModel();
        $res = $obj -> addAction('admin',$arr);
        if($res){
            echo '注册成功';
            header("refresh:1;url=".url('login/login_up'));
        }else{
            echo '注册失败';
            header("refresh:1;url=".url('login/login'));
        }
    }

    function login_upAction(){
        $this -> display('login/login_up');
    }
    function login_selectAction(){
        $account = empty($_POST['account'])?'':$_POST['account'];
        $pwd = empty($_POST['pwd'])?'':$_POST['pwd'];
        if(!$account){
            exit('账号不能为空');
        }
        if(!$pwd){
            exit('密码不能为空');
        }
        $obj = new \app\Model\UserModel();
        $where = "account='".$account."' and pwd='".$pwd."'";
        $res = $obj -> selectAction($where);
        if($res){
            echo '登陆成功';
            header("refresh:1;url=".url('login/Index'));
        }else{
            echo "<script>alert('请输入正确的账号密码')</script>";
            header("refresh:0;url=".url('login/login_up'));
        }
    }
    function listAction(){
        $p = empty($_GET['p']) ? 1 : $_GET['p'];
        $obj = new \app\Model\UserModel();
        $res = $obj -> pageAction($p,3);
        $count = $obj -> countAction();
        $page = new Page($count,3);
        $page_str = $page -> phpPage();
        $this -> assign('page_str',$page_str);
        $this -> assign('info',$res);
        $this -> display('login/Index');
    }
    function delAction(){
        $obj = new \app\Model\UserModel();
        $id = $_GET['id'];
        $where = 'id ='.$id;
        $res = $obj -> delAction($where);
        if($res){
            echo '删除成功';
            header("refresh:1;url=".url('login/Index'));
        }else{
            echo '删除失败';
            header("refresh:1;url=".url('login/Index'));
        }
    }
    function saveAction(){
        $obj = new \app\Model\UserModel();
        $id = $_GET['id'];
        $where = 'id ='.$id;
        $data = $obj -> findAction($where);
        $this -> assign('info',$data);
        $this -> display('login/save');
    }
    function updateAction(){
        $arr = $_POST;
        $obj = new \app\Model\UserModel();
        $where = 'id ='.$arr['id'];
        $res = $obj -> saveAction($arr,$where);
        if($res){
            echo '修改成功';
            header("refresh:1;url=".url('login/Index'));
        }else{
            echo '修改失败';
            header("refresh:1;url=".url('login/Index'));
        }
    }
}