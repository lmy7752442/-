<?php
namespace app\Controller;
use frameWork\Libr\Upload;
use app\Model\UserModel;
class FileloadController extends CommonController{
    function fileAction(){
        $this -> display('File/file');
    }
    function loadAction(){
        $file = $_FILES['file'];
        $obj = new Upload();
        $obj -> type = ['jpeg','jpg','png','gif','bmp'];
        $obj-> size = 1024*1024*2;
        $path = $obj -> up($file);
        $model = new UserModel();
        $arr['path'] = $path;
        $res = $model -> addAction('load_path',$arr);
        if($res){
            echo '添加成功';
            header("refresh:2;url=".url('fileload/Index'));
        }else{
            echo '添加失败';
        }
    }
    function listAction(){
        $model = new UserModel();
        $data = $model -> selectAction('load_path');
        $this -> assign('info',$data);
        $this -> display('File/Index');
    }
}