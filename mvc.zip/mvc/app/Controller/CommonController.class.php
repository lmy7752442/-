<?php
namespace app\Controller;
use framework\Core\Controller;
if(!defined('ROOT_PATH')){
	exit('not allow access');
}
class CommonController extends Controller {
	//function loadModel($model_name){
		//include ROOT_PATH.'/app/Model/'.$model_name.'Model.class.php';
		//$model_name = $model_name.'Model';
		//return new $model_name;
	//}
}
