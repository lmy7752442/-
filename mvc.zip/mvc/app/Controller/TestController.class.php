<?php
namespace app\Controller;
if(!defined('ROOT_PATH')){
	exit('not allow access');
}
class TestController{
	function testAction(){
		echo '这是test方法';
	}

}