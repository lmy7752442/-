<?php
namespace app\Controller;
if(!defined('ROOT_PATH')){
	exit('not allow access');
}
class IndexController{
	function indexAction(){
		echo '这是index方法';
	}

}