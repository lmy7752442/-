<table border="1">
    <tr>
        <td>账号</td>
        <td>密码</td>
    </tr>
    <?php foreach($info as $k => $v){
    echo "<tr>".
            "<td>".$v['account']."</td>".
            "<td>".$v['pwd']."</td>".
        "</tr>";

    }?>
</table>
