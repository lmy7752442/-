<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <form action="<?php echo url('Fileload/load') ?>" method="post" enctype="multipart/form-data">
        <input type="file" name="file"/>
        <br/>
        <input type="submit" value="上传"/>
    </form>
</body>
</html>