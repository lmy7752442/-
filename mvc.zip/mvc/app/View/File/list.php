<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<table>
    <tr>
        <td>id</td>
        <td>图片</td>
        <td>操作</td>
    </tr>
    <?php foreach($info as $k => $v){?>
    <tr>
        <td><?php echo $v['id']?></td>
        <td><img src="../../<?php echo $v['path']?>" width="50" height="50"/></td>
        <td><a href="">删除</a></td>
    </tr>
    <?php }?>
</table>
</body>
</html>