<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<form action="<?php echo url('login/update') ?>" method="post">
    <input type="hidden" name="id" value="<?php echo $info['id']?>"/>
    <h1>修改</h1>
    <table>
        <tr>
            <td>账号</td>
            <td><input type="text" name="account" value="<?php echo $info['account']?>"/></td>
        </tr>
        <tr>
            <td>密码</td>
            <td><input type="text" name="pwd" value="<?php echo $info['pwd']?>"/></td>
        </tr>
        <tr>
            <td><input type="submit" value="修改"/></td>
        </tr>
    </table>
</form>
</body>
</html>