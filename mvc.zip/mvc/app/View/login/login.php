<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <form action="<?php echo url('login/login_do') ?>" method="post">
        <h1>注册</h1>
        <table>
            <tr>
                <td>账号</td>
                <td><input type="text" name="account"/></td>
            </tr>
            <tr>
                <td>密码</td>
                <td><input type="password" name="pwd"/></td>
            </tr>
            <tr>
                <td><input type="submit" value="注册"/></td>
                <td></td>
            </tr>
        </table>
    </form>
</body>
</html>