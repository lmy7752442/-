<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<h1>展示</h1>
<table>
    <tr>
        <td>ID</td>
        <td>账号</td>
        <td>密码</td>
        <td>操作</td>
    </tr>
    <?php foreach($info as $k=>$v){?>
    <tr>
        <td><?php echo $v['id']?></td>
        <td><?php echo $v['account']?></td>
        <td><?php echo $v['pwd']?></td>
        <td>
            <a href="<?php echo url('login/del') ?>?id=<?php echo $v['id']?>">删除</a>
            <a href="<?php echo url('login/save') ?>?id=<?php echo $v['id']?>">修改</a>
        </td>
    </tr>
    <?php }?>
</table>
<?php echo $page_str;?>
</body>
</html>